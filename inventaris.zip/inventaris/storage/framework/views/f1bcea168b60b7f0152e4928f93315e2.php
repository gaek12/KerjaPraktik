<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/logo.png')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            background: url('<?php echo e(asset('images/backgroundlogin.png')); ?>') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', sans-serif;
        }

        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .login-card {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            padding: 2rem;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.37);
            color: #fff;
        }

        .login-card h2 {
            text-align: center;
            margin-bottom: 1.5rem;
            font-weight: bold;
        }

        label {
            color: #fff;
            margin-top: 1rem;
        }

        .form-control {
            width: 100%;
            padding: 0.75rem;
            border-radius: 6px;
            border: none;
            margin-top: 0.25rem;
        }

        .btn-login {
            width: 100%;
            background-color: #e60000;
            color: white;
            border: none;
            padding: 0.75rem;
            border-radius: 6px;
            font-weight: bold;
            margin-top: 1.5rem;
            transition: 0.3s ease;
        }

        .btn-login:hover {
            background-color: #cc0000;
        }

        .forgot-link {
            display: block;
            margin-top: 0.5rem;
            text-align: right;
            font-size: 0.875rem;
            color: #f0f0f0;
        }

        .forgot-link:hover {
            text-decoration: underline;
            color: #fff;
        }

        .error-message {
            font-size: 0.875rem;
            color: #ffcccc;
            margin-top: 0.25rem;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <h2>Login</h2>

            <!-- Session Status -->
            <?php if(session('status')): ?>
                <div class="mb-4 text-green-600">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <!-- Email Address -->
                <div>
                    <label for="email">Email</label>
                    <input id="email" class="form-control" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-message"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Password -->
                <div>
                    <label for="password">Password</label>
                    <input id="password" class="form-control" type="password" name="password" required>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error-message"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Forgot Password -->
                <?php if(Route::has('password.request')): ?>
                    <a class="forgot-link" href="<?php echo e(route('password.request')); ?>">
                        Forgot your password?
                    </a>
                <?php endif; ?>

                <!-- Submit -->
                <button type="submit" class="btn-login">Login</button>
            </form>
            <div class="text-center" style="font-size: 0.9rem;">
                <span>Belum memiliki akun? </span>
                <a href="<?php echo e(route('register')); ?>" style="color: #fff; font-weight: bold; text-decoration: underline;">
                    Daftar sini!
                </a>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\KerjaPraktik\inventaris\resources\views/auth/login.blade.php ENDPATH**/ ?>